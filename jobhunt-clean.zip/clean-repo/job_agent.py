"""
Job Hunting AI Agent
=====================
Helps you:
  1. Search jobs across multiple free platforms (LinkedIn, Wellfound, Naukri, etc.)
  2. Tailor your CV to each Job Description (JD)
  3. Generate a customised cover letter for each role
  4. Prepare everything for your review, then open the application page
     in your browser — YOU click apply, not the bot.

DESIGN PHILOSOPHY:
  - Semi-automatic: The agent PREPARES, you DECIDE and SUBMIT.
    This is intentional. Auto-submitting applications with AI-generated
    content is risky — some platforms detect and block bots, and you want
    to review each application anyway.
  - The agent saves everything to a local folder structure so you have
    a complete application tracker.

USAGE:
  python job_agent.py --search "Product Operations Manager remote India"
  python job_agent.py --search "Business Intelligence Analyst remote"
  python job_agent.py --tailor --jd jd.txt --job-title "Product Ops Manager" --company "Razorpay"
  python job_agent.py --interactive    # Full guided mode

PREREQUISITES:
  pip install openai pandas

  You'll need an OpenAI API key for CV tailoring and cover letter generation.
  Set it as an environment variable:
    export OPENAI_API_KEY="sk-..."
  Or save it in a file called .env in the same folder.

NOTE: This agent does NOT auto-apply. It prepares everything and opens
the application URL in your browser. You review and click submit yourself.
"""

import argparse
import json
import os
import re
import sys
import webbrowser
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

try:
    import pandas as pd
except ImportError:
    os.system("pip install pandas")
    import pandas as pd

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


# ============================================================
# CONFIGURATION
# ============================================================

@dataclass
class AgentConfig:
    """Configuration for the job hunting agent."""
    # Paths
    base_dir: str = "job_applications"
    cv_template: str = "Ashish_Goud_Remote_Ops_CV.docx"
    tracker_file: str = "application_tracker.csv"

    # Search
    max_results_per_platform: int = 10

    # Job boards to search (with search URL templates)
    # {query} is replaced with the URL-encoded search query
    job_boards: dict = field(default_factory=lambda: {
        "LinkedIn Jobs": "https://www.linkedin.com/jobs/search/?keywords={query}&f_WT=2&location=India",
        "Wellfound": "https://wellfound.com/role/r/{query}",
        "Naukri": "https://www.naukri.com/{query}-jobs-in-india",
        "We Work Remotely": "https://weworkremotely.com/remote-jobs/search?term={query}",
        "Remote.co": "https://remote.co/remote-jobs/search/?search_keywords={query}",
        "Himalayas": "https://himalayas.app/jobs?search={query}",
        "Instahyre": "https://www.instahyre.com/search?q={query}",
        "Otta": "https://app.otta.com/search?q={query}",
    })

    # Your profile (for CV tailoring and cover letters)
    profile: dict = field(default_factory=lambda: {
        "name": "Ashish Goud",
        "email": "g.ashishgoud@gmail.com",
        "phone": "+91 9010401111",
        "location": "Hyderabad, India",
        "headline": "Product & Operations Manager | 12+ yrs in Business Operations, P&L & BI Dashboards",
        "key_skills": [
            "Product Lifecycle Ownership", "Operations Management", "P&L Ownership",
            "Business Development", "Strategic Partnerships", "Stakeholder Management",
            "Cross-Functional Leadership", "Power BI", "Tableau", "Salesforce Reporting",
            "Advanced Excel", "Dashboard Development", "Business Intelligence",
            "KPI Management", "Data-Driven Decision Making",
        ],
        "experience_years": 12,
        "current_role": "Founder & Director, AB Infra Developers",
        "education": "MBA (University of Sunderland, UK affiliation), B.Pharm",
        "summary": (
            "Operations and product leader with 12+ years of experience running multi-site operations, "
            "owning P&L for multi-crore monthly businesses, and building self-authored BI dashboards "
            "in Power BI and Tableau. Led teams of 50+ across 23+ locations. Seeking remote operations "
            "or business-intelligence roles."
        ),
    })


# ============================================================
# JOB SEARCH
# ============================================================

class JobSearcher:
    """
    Searches for jobs across multiple free platforms.
    Generates search URLs for each platform and opens them in the browser.

    NOTE: This does not scrape results. It opens search pages in your browser
    so you can browse and save job descriptions. Scraping job platforms
    violates their Terms of Service and can get your account banned.

    For a more automated approach in the future, you can use:
    - LinkedIn Jobs API (requires LinkedIn developer access)
    - Jooble API (free, limited)
    - Adzuna API (free tier available)
    """

    def __init__(self, config: AgentConfig):
        self.config = config

    def search(self, query: str, open_in_browser: bool = True) -> dict:
        """
        Generate search URLs for all platforms and optionally open them.
        Returns a dict of {platform: url}.
        """
        encoded_query = query.replace(" ", "-").lower()
        encoded_query_url = query.replace(" ", "+").lower()

        urls = {}
        print("\n" + "=" * 60)
        print("  JOB SEARCH RESULTS")
        print("=" * 60)
        print(f"  Query: {query}")
        print(f"  Platforms: {len(self.config.job_boards)}")
        print("=" * 60)

        for platform, url_template in self.config.job_boards.items():
            # Use appropriate encoding
            if "linkedin" in platform.lower() or "weworkremotely" in platform.lower() or "remote.co" in platform.lower() or "himalayas" in platform.lower() or "instahyre" in platform.lower() or "otta" in platform.lower():
                url = url_template.replace("{query}", encoded_query_url)
            else:
                url = url_template.replace("{query}", encoded_query)
            urls[platform] = url

            print(f"\n  {platform}:")
            print(f"  {url}")

            if open_in_browser:
                try:
                    webbrowser.open(url)
                except Exception:
                    pass

        print("\n" + "=" * 60)
        print("  All search pages opened in your browser.")
        print("  Browse each platform, save interesting job descriptions")
        print("  to a text file, then use --tailor to customise your CV.")
        print("=" * 60 + "\n")

        return urls

    def save_search(self, query: str, urls: dict):
        """Save search results to the tracker."""
        search_dir = Path(self.config.base_dir) / "searches"
        search_dir.mkdir(parents=True, exist_ok=True)

        search_file = search_dir / f"search_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(search_file, 'w') as f:
            json.dump({
                "query": query,
                "timestamp": datetime.now().isoformat(),
                "urls": urls,
            }, f, indent=2)

        print(f"  Search saved to: {search_file}")


# ============================================================
# JD ANALYSIS
# ============================================================

class JDAnalyser:
    """
    Analyses a Job Description to extract:
    - Key skills required
    - Role title
    - Company name (if provided)
    - Key responsibilities
    - Keywords to emphasise in CV
    """

    def __init__(self, config: AgentConfig):
        self.config = config
        self.client = None
        if HAS_OPENAI and os.environ.get("OPENAI_API_KEY"):
            self.client = OpenAI()

    def analyse(self, jd_text: str) -> dict:
        """Analyse a JD and return structured data."""
        if not self.client:
            print("  [!] OpenAI API not available. Using basic keyword extraction.")
            return self._basic_analysis(jd_text)

        print("\n  Analysing Job Description with AI...")

        prompt = f"""
        Analyse this Job Description and extract the following as JSON:
        {{
            "role_title": "extracted role title",
            "key_skills": ["skill1", "skill2", ...],
            "key_responsibilities": ["resp1", "resp2", ...],
            "keywords_to_emphasise": ["keyword1", "keyword2", ...],
            "seniority_level": "junior/mid/senior/lead",
            "remote_or_onsite": "remote/hybrid/onsite",
            "salary_range": "extracted if mentioned, else 'not mentioned'",
            "must_have_vs_nice_to_have": {{
                "must_have": ["skill1", ...],
                "nice_to_have": ["skill1", ...]
            }}
        }}

        Job Description:
        {jd_text[:3000]}

        Return ONLY valid JSON, no additional text.
        """

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an expert recruitment analyst. Return only valid JSON."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
            )

            result = response.choices[0].message.content.strip()
            # Clean up any markdown formatting
            result = result.replace("```json", "").replace("```", "").strip()

            analysis = json.loads(result)
            print("  [OK] JD analysis complete.")
            return analysis

        except Exception as e:
            print(f"  [!] AI analysis failed: {e}")
            print("  Falling back to basic keyword extraction.")
            return self._basic_analysis(jd_text)

    def _basic_analysis(self, jd_text: str) -> dict:
        """Basic keyword extraction without AI."""
        # Common job skills to look for
        skill_keywords = [
            "operations", "product", "analytics", "Power BI", "Tableau", "Excel",
            "SQL", "dashboard", "BI", "P&L", "stakeholder", "cross-functional",
            "project management", "process improvement", "business development",
            "KPI", "metrics", "data-driven", "remote", "RevOps", "customer success",
            "strategy", "leadership", "vendor management", "procurement",
        ]

        jd_lower = jd_text.lower()
        found_skills = [s for s in skill_keywords if s.lower() in jd_lower]

        # Try to extract role title
        role_patterns = [
            r"(?:hiring|seeking|looking for)\s+(?:a|an)\s+(.+?)(?:\s+(?:to|who|with|that|\.|,))",
            r"(?:position|role|title):\s*(.+?)(?:\n|$)",
            r"^#\s*(.+?)$",
        ]

        role_title = "Unknown"
        for pattern in role_patterns:
            match = re.search(pattern, jd_text, re.IGNORECASE | re.MULTILINE)
            if match:
                role_title = match.group(1).strip()
                break

        return {
            "role_title": role_title,
            "key_skills": found_skills,
            "key_responsibilities": [],
            "keywords_to_emphasise": found_skills,
            "seniority_level": "mid" if "3+" in jd_text or "5+" in jd_text else "unknown",
            "remote_or_onsite": "remote" if "remote" in jd_lower else "unknown",
            "salary_range": "not mentioned",
            "must_have_vs_nice_to_have": {"must_have": found_skills, "nice_to_have": []},
        }


# ============================================================
# CV TAILORING
# ============================================================

class CVTailor:
    """
    Tailors the CV summary and skills section to match a specific JD.
    Does NOT fabricate experience — only reorders, rephrases, and emphasises
    existing skills and experience that match the JD.
    """

    def __init__(self, config: AgentConfig):
        self.config = config
        self.client = None
        if HAS_OPENAI and os.environ.get("OPENAI_API_KEY"):
            self.client = OpenAI()

    def tailor(self, jd_analysis: dict, job_title: str = "", company: str = "") -> str:
        """
        Generate a tailored CV summary and skills emphasis based on JD analysis.
        Returns the tailored content as a text string.
        """
        profile = self.config.profile

        if not self.client:
            print("  [!] OpenAI API not available. Using basic tailoring.")
            return self._basic_tailor(jd_analysis, job_title, company)

        print("\n  Tailoring CV with AI...")

        prompt = f"""
        You are an expert CV writer. Tailor the following professional profile
        to match the Job Description analysis. Rules:
        1. Do NOT fabricate experience or skills that are not in the profile.
        2. Reorder and emphasise skills that match the JD's must-have skills.
        3. Rewrite the professional summary to speak directly to this role.
        4. Generate a "Key Skills for This Role" section that highlights
           the intersection of the candidate's skills and the JD requirements.
        5. Keep the tone professional, confident, and concise.

        Return the result as:

        === PROFESSIONAL SUMMARY ===
        [2-3 sentence tailored summary]

        === KEY SKILLS FOR THIS ROLE ===
        - [skill1]
        - [skill2]
        ...

        === COVER LETTER ANGLE ===
        [1-2 sentences describing the unique angle for the cover letter —
         why this candidate is a strong fit for this specific role]

        CANDIDATE PROFILE:
        Name: {profile['name']}
        Headline: {profile['headline']}
        Experience: {profile['experience_years']} years
        Current Role: {profile['current_role']}
        Education: {profile['education']}
        Key Skills: {', '.join(profile['key_skills'])}
        Summary: {profile['summary']}

        JOB DESCRIPTION ANALYSIS:
        Role: {job_title or jd_analysis.get('role_title', 'Unknown')}
        Company: {company or 'Unknown'}
        Must-have skills: {', '.join(jd_analysis.get('must_have_vs_nice_to_have', {}).get('must_have', []))}
        Key skills: {', '.join(jd_analysis.get('key_skills', []))}
        Keywords to emphasise: {', '.join(jd_analysis.get('keywords_to_emphasise', []))}
        Seniority: {jd_analysis.get('seniority_level', 'mid')}
        """

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an expert CV writer and career coach."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.5,
            )

            result = response.choices[0].message.content.strip()
            print("  [OK] CV tailored.")
            return result

        except Exception as e:
            print(f"  [!] AI tailoring failed: {e}")
            return self._basic_tailor(jd_analysis, job_title, company)

    def _basic_tailor(self, jd_analysis: dict, job_title: str, company: str) -> str:
        """Basic tailoring without AI."""
        profile = self.config.profile
        jd_skills = set(s.lower() for s in jd_analysis.get("key_skills", []))
        candidate_skills = profile["key_skills"]

        # Find matching skills
        matching = [s for s in candidate_skills if s.lower() in jd_skills]
        # Find skills not in JD but still relevant
        other = [s for s in candidate_skills if s.lower() not in jd_skills]

        tailored_summary = (
            f"Results-oriented {job_title or 'Operations Professional'} with {profile['experience_years']}+ years "
            f"of experience in operations management, P&L ownership, and BI dashboard development. "
            f"Seeking to bring operational rigour and data fluency to {company or 'a growth-focused organisation'}. "
            f"Proven ability to lead cross-functional teams, manage multi-crore operations, and build "
            f"self-authored Power BI and Tableau dashboards that drive decision-making."
        )

        result = "=== PROFESSIONAL SUMMARY ===\n"
        result += tailored_summary + "\n\n"
        result += "=== KEY SKILLS FOR THIS ROLE ===\n"
        for skill in matching[:8]:
            result += f"- {skill}\n"
        for skill in other[:4]:
            result += f"- {skill}\n"
        result += "\n=== COVER LETTER ANGLE ===\n"
        result += (
            f"Highlight the intersection of your operations leadership (12+ years, 23+ locations, "
            f"teams of 50+) with the JD's focus on {', '.join(jd_analysis.get('key_skills', [])[:3])}. "
            f"Emphasise your ability to build BI dashboards — a rare combination of operator + analyst."
        )

        return result


# ============================================================
# COVER LETTER GENERATOR
# ============================================================

class CoverLetterGenerator:
    """
    Generates a customised cover letter for each job application.
    """

    def __init__(self, config: AgentConfig):
        self.config = config
        self.client = None
        if HAS_OPENAI and os.environ.get("OPENAI_API_KEY"):
            self.client = OpenAI()

    def generate(self, jd_analysis: dict, tailored_content: str,
                 job_title: str = "", company: str = "") -> str:
        """Generate a cover letter."""
        profile = self.config.profile

        if not self.client:
            print("  [!] OpenAI API not available. Using template-based cover letter.")
            return self._template_cover_letter(jd_analysis, job_title, company)

        print("\n  Generating cover letter with AI...")

        prompt = f"""
        Write a professional, concise cover letter (250-350 words) for the following
        job application. Rules:
        1. Do NOT fabricate experience. Use only the facts in the candidate profile.
        2. Address it to "Dear Hiring Manager" if no specific name is available.
        3. Open with a strong hook — why this specific role at this specific company.
        4. Body: 2 paragraphs connecting the candidate's experience to the JD requirements.
           Use specific numbers and achievements.
        5. Close with a call to action — request an interview.
        6. Tone: professional, confident, warm. Not desperate or overly formal.
        7. Sign off as: {profile['name']}

        CANDIDATE PROFILE:
        Name: {profile['name']}
        Headline: {profile['headline']}
        Experience: {profile['experience_years']} years
        Current Role: {profile['current_role']}
        Key Skills: {', '.join(profile['key_skills'])}
        Summary: {profile['summary']}

        JOB DETAILS:
        Role: {job_title or jd_analysis.get('role_title', 'the position')}
        Company: {company or 'your organisation'}
        Key JD Skills: {', '.join(jd_analysis.get('key_skills', [])[:5])}
        Must-have skills: {', '.join(jd_analysis.get('must_have_vs_nice_to_have', {}).get('must_have', [])[:5])}

        TAILORED CONTENT (from CV tailoring):
        {tailored_content[:1000]}

        Return ONLY the cover letter text, no meta-commentary.
        """

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an expert cover letter writer."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.6,
            )

            letter = response.choices[0].message.content.strip()
            print("  [OK] Cover letter generated.")
            return letter

        except Exception as e:
            print(f"  [!] AI cover letter generation failed: {e}")
            return self._template_cover_letter(jd_analysis, job_title, company)

    def _template_cover_letter(self, jd_analysis: dict, job_title: str, company: str) -> str:
        """Generate a basic cover letter without AI."""
        profile = self.config.profile
        role = job_title or jd_analysis.get("role_title", "the open position")
        comp = company or "your organisation"
        key_skills = jd_analysis.get("key_skills", [])

        return f"""Dear Hiring Manager,

I am writing to express my interest in the {role} position at {comp}. With over 12 years of experience in operations management, P&L ownership, and business intelligence, I believe I bring a unique blend of operational rigour and data fluency that aligns closely with what this role demands.

In my current role as Founder & Director at AB Infra Developers, I have owned the full lifecycle of 10+ residential projects and 8 villa developments — managing budgets, vendor relationships, and quality control across multiple simultaneous sites. Previously, as Junior Data Analyst at Huber & Holly (HRPL), I built Tableau and Salesforce dashboards that became the standard reporting layer for management decision-making across 18 outlets generating 8-20 Lakhs monthly revenue each. This combination — hands-on operator who also builds the BI tools — is what I bring to {comp}.

My key strengths that are particularly relevant to this role include {', '.join(key_skills[:4]) if key_skills else 'operations management, process improvement, and data-driven decision making'}. I am comfortable working in cross-functional, remote environments and am adept at stakeholder management across all levels.

I would welcome the opportunity to discuss how my experience can contribute to {comp}'s growth. Thank you for considering my application.

Warm regards,
{profile['name']}
{profile['email']}
{profile['phone']}
"""


# ============================================================
# APPLICATION TRACKER
# ============================================================

class ApplicationTracker:
    """
    Tracks all job applications in a CSV file.
    Each application gets its own folder with the tailored CV,
    cover letter, and JD analysis.
    """

    def __init__(self, config: AgentConfig):
        self.config = config
        self.tracker_path = Path(config.base_dir) / config.tracker_file

    def record(self, job_title: str, company: str, jd_analysis: dict,
               tailored_content: str, cover_letter: str, source: str = ""):
        """Record a new application in the tracker."""
        # Create folder for this application
        safe_company = re.sub(r'[^a-zA-Z0-9]', '_', company or "unknown")
        safe_title = re.sub(r'[^a-zA-Z0-9]', '_', job_title or "unknown")
        folder_name = f"{datetime.now().strftime('%Y%m%d')}_{safe_company}_{safe_title}"[:80]
        app_dir = Path(self.config.base_dir) / folder_name
        app_dir.mkdir(parents=True, exist_ok=True)

        # Save JD analysis
        with open(app_dir / "jd_analysis.json", 'w') as f:
            json.dump(jd_analysis, f, indent=2)

        # Save tailored content
        with open(app_dir / "tailored_cv_content.txt", 'w') as f:
            f.write(tailored_content)

        # Save cover letter
        with open(app_dir / "cover_letter.txt", 'w') as f:
            f.write(cover_letter)

        # Update CSV tracker
        row = {
            "date": datetime.now().strftime('%Y-%m-%d'),
            "company": company,
            "job_title": job_title,
            "status": "prepared",
            "source": source,
            "folder": folder_name,
            "key_skills_matched": ", ".join(jd_analysis.get("key_skills", [])[:5]),
            "applied": "No",
            "follow_up_date": (datetime.now().replace(day=datetime.now().day + 7)).strftime('%Y-%m-%d') if datetime.now().day <= 21 else "",
        }

        df_new = pd.DataFrame([row])
        if self.tracker_path.exists():
            df_existing = pd.read_csv(self.tracker_path)
            df = pd.concat([df_existing, df_new], ignore_index=True)
        else:
            df = df_new

        df.to_csv(self.tracker_path, index=False)
        print(f"\n  [OK] Application recorded in tracker.")
        print(f"  Folder: {app_dir}")
        print(f"  Tracker: {self.tracker_path}")

        return app_dir

    def summary(self):
        """Print summary of all applications."""
        if not self.tracker_path.exists():
            print("\n  No applications tracked yet.")
            return

        df = pd.read_csv(self.tracker_path)
        print(f"\n{'='*60}")
        print("  APPLICATION TRACKER SUMMARY")
        print(f"{'='*60}")
        print(f"  Total applications prepared: {len(df)}")
        print(f"  Applied: {len(df[df['applied'] == 'Yes']) if 'applied' in df.columns else 0}")
        print(f"  Pending: {len(df[df['applied'] == 'No']) if 'applied' in df.columns else len(df)}")
        print(f"\n  Recent applications:")
        print(df.tail(10).to_string(index=False))
        print(f"{'='*60}")


# ============================================================
# MAIN AGENT
# ============================================================

class JobHuntingAgent:
    """
    The main agent that orchestrates job search, CV tailoring,
    cover letter generation, and application tracking.
    """

    def __init__(self, config: AgentConfig = None):
        self.config = config or AgentConfig()
        self.searcher = JobSearcher(self.config)
        self.analyser = JDAnalyser(self.config)
        self.tailor = CVTailor(self.config)
        self.letter_gen = CoverLetterGenerator(self.config)
        self.tracker = ApplicationTracker(self.config)

    def search_jobs(self, query: str):
        """Search for jobs across all platforms."""
        urls = self.searcher.search(query, open_in_browser=True)
        self.searcher.save_search(query, urls)
        return urls

    def prepare_application(self, jd_text: str, job_title: str = "",
                             company: str = "", source: str = ""):
        """
        Full pipeline: analyse JD -> tailor CV -> generate cover letter
        -> save everything -> open for review.

        YOU then review and apply manually.
        """
        print("\n" + "=" * 60)
        print("  JOB HUNTING AGENT - APPLICATION PREPARATION")
        print("=" * 60)
        print(f"  Role: {job_title or 'Auto-detect from JD'}")
        print(f"  Company: {company or 'Unknown'}")
        print("=" * 60)

        # Step 1: Analyse JD
        print("\n  [Step 1/4] Analysing Job Description...")
        jd_analysis = self.analyser.analyse(jd_text)
        print(f"  Role detected: {jd_analysis.get('role_title', 'Unknown')}")
        print(f"  Key skills found: {', '.join(jd_analysis.get('key_skills', [])[:5])}")
        print(f"  Seniority: {jd_analysis.get('seniority_level', 'unknown')}")

        # Step 2: Tailor CV
        print("\n  [Step 2/4] Tailoring CV...")
        tailored = self.tailor.tailor(jd_analysis, job_title, company)
        print("\n  --- TAILORED CV CONTENT ---")
        print(tailored)

        # Step 3: Generate Cover Letter
        print("\n  [Step 3/4] Generating Cover Letter...")
        cover_letter = self.letter_gen.generate(jd_analysis, tailored, job_title, company)
        print("\n  --- COVER LETTER ---")
        print(cover_letter)

        # Step 4: Save and track
        print("\n  [Step 4/4] Saving application...")
        app_dir = self.tracker.record(job_title, company, jd_analysis, tailored, cover_letter, source)

        # Ask for permission to open application
        print("\n" + "=" * 60)
        print("  EVERYTHING IS PREPARED.")
        print("=" * 60)
        print(f"  Folder: {app_dir}")
        print(f"  Files saved:")
        print(f"    - jd_analysis.json (JD breakdown)")
        print(f"    - tailored_cv_content.txt (CV modifications)")
        print(f"    - cover_letter.txt (cover letter)")
        print(f"    - application_tracker.csv (master tracker)")
        print("=" * 60)

        # Print the application URL if source is provided
        if source:
            print(f"\n  Application URL: {source}")
            print("  Opening in browser for your review...")
            try:
                webbrowser.open(source)
            except Exception:
                pass

        print("\n  >>> REVIEW the tailored content and cover letter. <<<")
        print("  >>> Edit if needed in the saved files. <<<")
        print("  >>> Then apply MANUALLY on the platform. <<<")
        print("  >>> After applying, run: python job_agent.py --mark-applied")
        print("=" * 60 + "\n")

        return app_dir

    def interactive_mode(self):
        """Full guided interactive mode."""
        print("\n" + "=" * 60)
        print("  JOB HUNTING AI AGENT - INTERACTIVE MODE")
        print("=" * 60)

        print("""
  What would you like to do?

  1. Search for jobs (opens search pages in browser)
  2. Prepare an application (paste JD, get tailored CV + cover letter)
  3. View application tracker summary
  4. Mark an application as applied
  5. Exit
        """)

        choice = input("  Enter choice (1-5): ").strip()

        if choice == "1":
            query = input("  Enter search query (e.g. 'Product Operations Manager remote India'): ").strip()
            if query:
                self.search_jobs(query)

        elif choice == "2":
            print("\n  Paste the Job Description below.")
            print("  Type '---' on a new line when done, or press Ctrl+C to cancel.\n")

            lines = []
            try:
                while True:
                    line = input()
                    if line.strip() == "---":
                        break
                    lines.append(line)
            except (KeyboardInterrupt, EOFError):
                print("\n  Cancelled.")
                return

            jd_text = "\n".join(lines)
            if not jd_text.strip():
                print("  No JD provided. Exiting.")
                return

            job_title = input("  Enter job title (or press Enter to auto-detect): ").strip()
            company = input("  Enter company name (or press Enter if unknown): ").strip()
            source = input("  Enter application URL (or press Enter to skip): ").strip()

            self.prepare_application(jd_text, job_title, company, source)

        elif choice == "3":
            self.tracker.summary()

        elif choice == "4":
            self._mark_applied()

        elif choice == "5":
            print("  Goodbye!")
            return

        else:
            print("  Invalid choice.")

        # Loop back
        print()
        self.interactive_mode()

    def _mark_applied(self):
        """Mark an application as applied in the tracker."""
        if not self.tracker.tracker_path.exists():
            print("  No applications tracked yet.")
            return

        df = pd.read_csv(self.tracker.tracker_path)
        pending = df[df['applied'] == 'No'] if 'applied' in df.columns else df

        if len(pending) == 0:
            print("  No pending applications. All marked as applied.")
            return

        print("\n  Pending applications:")
        for i, (_, row) in enumerate(pending.iterrows()):
            print(f"  {i+1}. {row['company']} - {row['job_title']} ({row['date']})")

        try:
            idx = int(input("\n  Enter number to mark as applied: ")) - 1
            if 0 <= idx < len(pending):
                # Get the actual index in the original dataframe
                actual_idx = pending.index[idx]
                df.loc[actual_idx, 'applied'] = 'Yes'
                df.loc[actual_idx, 'status'] = 'applied'
                df.to_csv(self.tracker.tracker_path, index=False)
                print(f"  [OK] Marked as applied: {df.loc[actual_idx, 'company']} - {df.loc[actual_idx, 'job_title']}")
            else:
                print("  Invalid number.")
        except (ValueError, IndexError):
            print("  Invalid input.")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Job Hunting AI Agent - Search, Tailor CV, Generate Cover Letter"
    )
    parser.add_argument('--interactive', action='store_true',
                        help="Run in full guided interactive mode")
    parser.add_argument('--search', type=str,
                        help="Search for jobs with this query")
    parser.add_argument('--tailor', action='store_true',
                        help="Tailor CV and generate cover letter from a JD file")
    parser.add_argument('--jd', type=str,
                        help="Path to a text file containing the Job Description")
    parser.add_argument('--job-title', type=str, default="",
                        help="Job title (for --tailor mode)")
    parser.add_argument('--company', type=str, default="",
                        help="Company name (for --tailor mode)")
    parser.add_argument('--source', type=str, default="",
                        help="Application URL (for --tailor mode)")
    parser.add_argument('--summary', action='store_true',
                        help="Show application tracker summary")
    parser.add_argument('--mark-applied', action='store_true',
                        help="Mark an application as applied")

    args = parser.parse_args()
    agent = JobHuntingAgent()

    if args.interactive:
        agent.interactive_mode()

    elif args.search:
        agent.search_jobs(args.search)

    elif args.tailor:
        if not args.jd:
            print("  Error: --jd (path to JD file) is required for --tailor mode.")
            print("  Usage: python job_agent.py --tailor --jd jd.txt --job-title 'Product Ops' --company 'Razorpay'")
            return

        jd_path = Path(args.jd)
        if not jd_path.exists():
            print(f"  Error: JD file not found: {args.jd}")
            return

        with open(jd_path, 'r') as f:
            jd_text = f.read()

        agent.prepare_application(jd_text, args.job_title, args.company, args.source)

    elif args.summary:
        agent.tracker.summary()

    elif args.mark_applied:
        agent._mark_applied()

    else:
        print("""
  Job Hunting AI Agent
  ---------------------
  This agent helps you:
    1. Search jobs across 8 free platforms
    2. Tailor your CV to each Job Description
    3. Generate a customised cover letter
    4. Track all applications in a CSV file
    5. Prepare everything for YOUR review — you click apply

  Usage:
    python job_agent.py --interactive
    python job_agent.py --search "Product Operations Manager remote India"
    python job_agent.py --tailor --jd jd.txt --job-title "Product Ops Manager" --company "Razorpay"
    python job_agent.py --summary
    python job_agent.py --mark-applied

  Setup:
    pip install openai pandas
    export OPENAI_API_KEY="sk-..."   (for AI-powered tailoring)

  Note: This agent does NOT auto-apply. It prepares everything and
  opens the application URL in your browser. You review and submit.
        """)


if __name__ == "__main__":
    main()
